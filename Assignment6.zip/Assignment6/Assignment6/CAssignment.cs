﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment6
{
    class CAssignment
    {

        public int[] ArrMethod(int[] arr1)
        {
            int len = arr1.Length;
            int[] arr2 = new int[len * 2];
            int i;
            for (i = 0; i < len; i++) arr2[i] = arr1[i];
            for (int j = 0; j < len; j++)
            {
                arr2[i] = arr1[j];
                i++;
            }
            /*for(int n=0; n < arr2.Length; n++)
            {
                Console.WriteLine(arr2[n]);
            }*/
            return arr2;
        }
    }
}
