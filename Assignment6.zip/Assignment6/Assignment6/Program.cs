﻿namespace Assignment6
{
    public class Program
    {
        public static void Main()
        {
            CAssignment run1 = new CAssignment();
            int[] arr = { 1, 2, 3, 4, 5 };
            int[] output;
            output = run1.ArrMethod(arr);
            for(int i = 0; i < output.Length; i++)
            {
                Console.WriteLine(output[i]);
            }
        }
    }
}